
<?php
  echo 'Hello world!';
?>

<!DOCTYPE html>
<html>
  <head>
    <title>PHP Example</title>
  </head>
  <body>
    <p><?php echo $message; ?></p>
  </body>
</html>
