
<?php

// Single line comment

/*
  Multi-line comment
*/

$variable = true;

$array = [1, 2, 3];

echo '<pre>';
var_dump($array);
echo '</pre>';

?>
