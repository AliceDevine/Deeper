<?php

// Some other logic...

header("Location: my-file.php");
// or
header("Location: http://google.co.uk");

// Kill the script
die();
