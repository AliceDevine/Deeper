<?php

function addNumbers($a, $b) {
  return $a + $b;
}

$sum = addNumbers(3, 5); // 8
