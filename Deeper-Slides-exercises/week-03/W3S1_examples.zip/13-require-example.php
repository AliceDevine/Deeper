
// ----------------------------------------
// mainFile.php

<?php
  require_once 'myFile.php';
  echo 'Hello from the main file!';
?>


// ----------------------------------------
// myFile.php

<?php
  echo 'Hello from the required file!<br>';
?>
