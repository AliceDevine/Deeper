<?php

echo 'Hello from the required file!<br>';
