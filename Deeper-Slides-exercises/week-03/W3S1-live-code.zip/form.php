<?php

if (!empty($_POST)) {
    var_dump($_POST);
}

?>
<html>
<body>
<form action="" method="post">
    <label for="search-term">Search Term:</label>
    <input type="text" name="SearchTerm" id="search-term">

    <button type="submit">Search</button>
</form>
</body>
</html>
