<?php

echo 'Hello World!';

$array = ['Chris', 'Danny', 'Jeremy'];

var_dump($array);

$array2 = array('Jeremy', 'Nicola', 'Gaby');

var_dump($array2);

print_r(array_merge($array, $array2));
